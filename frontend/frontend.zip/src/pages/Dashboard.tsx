import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import useBodyClass from "../hooks/useBodyClass";
import "../styles/Dashboard.css";
import { useAuth } from "../hooks/useAuth";
import petworkinglogo from "../assets/PetWorking.png";

interface Pet {
  id_pet: number;
  nome: string;
  idade: number;
  especie: string;
  raca: string;
  foto: string;
}

interface Servico {
  id_servico: number;
  nome: string;
  descricao: string;
  preco: number;
}

interface Agendamento {
  id_agendamento: number;
  data: string;
  horario: string;
  status: string;
  pet: {
    nome: string;
  };
  servico: {
    nome: string;
  };
}

const Dashboard = () => {
  useBodyClass("dashboard-page");
  const { user, logout } = useAuth();
  const location = useLocation();
  
  const [pets, setPets] = useState<Pet[]>([]);
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuMobile, setMenuMobile] = useState(false);

  useEffect(() => {
    // Simulando carregamento de dados (em um cenário real, aqui você faria chamadas à API)
    const fetchData = async () => {
      try {
        // Aqui você faria chamadas à API real
        // const petsResponse = await api.get('/pets');
        // const agendamentosResponse = await api.get('/agendamentos');
        // const servicosResponse = await api.get('/servicos');
        
        // Dados mockados para exemplo
        setPets([
          { id_pet: 2, nome: "Luna", idade: 2, especie: "Gato", raca: "Siamês", foto: "https://i.imgur.com/random2.jpg" }
        
        ]);
        
        setAgendamentos([
          { id_agendamento: 1, data: "2025-03-20", horario: "14:00", status: "Agendado", pet: { nome: "Rex" }, servico: { nome: "Consulta" } },
        ]);
        
        setServicos([
          { id_servico: 2, nome: "Banho e Tosa", descricao: "Limpeza e cuidados estéticos", preco: 80 },
        ]);
        
        setLoading(false);
      } catch (error) {
        console.error("Erro ao carregar dados:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const formatarData = (dataString: string) => {
    const data = new Date(dataString);
    return data.toLocaleDateString('pt-BR');
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  const handleLogout = () => {
    if (logout) logout();
  };

  const toggleMobileMenu = () => {
    setMenuMobile(!menuMobile);
  };

  if (loading) {
    return <div className="loading">Carregando informações...</div>;
  }

  return (
    <div className="dashboard-layout">
      {/* Barra de navegação lateral */}
      <aside className={`sidebar ${menuMobile ? 'sidebar-mobile-active' : ''}`}>
        <div className="sidebar-header">

            <img src={petworkinglogo} alt="PetWorking" className="logo-image"   />
          <button 
            className="close-menu-btn" 
            onClick={toggleMobileMenu}
            aria-label="Fechar menu"
          >
            &times;
          </button>
        </div>
        
        <div className="user-profile">
          <div className="user-avatar">
            {user?.nome?.charAt(0) || "U"}
          </div>
          <div className="user-name">{user?.nome || "Usuário"}</div>
        </div>
        
        <nav className="sidebar-nav">
          <ul>
            <li>
              <Link to="/dashboard" className={isActive("/dashboard") ? "active" : ""}>
                <span className="nav-icon">🏠</span>
                Dashboard
              </Link>
            </li>
            <li>
              <Link to="/pets" className={isActive("/pets") ? "active" : ""}>
                <span className="nav-icon">🐾</span>
                Meus Pets
              </Link>
            </li>
            <li>
              <Link to="/agendamentos" className={isActive("/agendamentos") ? "active" : ""}>
                <span className="nav-icon">📅</span>
                Agendamentos
              </Link>
            </li>
            <li>
              <Link to="/servicos" className={isActive("/servicos") ? "active" : ""}>
                <span className="nav-icon">💉</span>
                Serviços
              </Link>
            </li>
            <li>
              <Link to="/historico" className={isActive("/historico") ? "active" : ""}>
                <span className="nav-icon">📋</span>
                Histórico
              </Link>
            </li>
            <li>
              <Link to="/configuracoes" className={isActive("/configuracoes") ? "active" : ""}>
                <span className="nav-icon">⚙️</span>
                Configurações
              </Link>
            </li>
          </ul>
        </nav>
        
        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            <span className="nav-icon">🚪</span>
            Sair
          </button>
        </div>
      </aside>

      {/* Conteúdo principal */}
      <main className="main-content">
        {/* Header para dispositivos móveis */}
        <header className="mobile-header">
          <button 
            className="menu-toggle" 
            onClick={toggleMobileMenu}
            aria-label="Abrir menu"
          >
            ☰
          </button>
          <h1>PetCare</h1>
          <div className="mobile-user">
            <div className="user-avatar-small">{user?.nome?.charAt(0) || "U"}</div>
          </div>
        </header>
        
        {/* Seção de Resumo */}
        <section className="dashboard-section summary-section">
          <h2>Resumo</h2>
          <div className="summary-cards">
            <div className="summary-card">
              <div className="summary-icon pet-icon">🐾</div>
              <div className="summary-details">
                <h3>Pets</h3>
                <p className="summary-value">{pets.length}</p>
              </div>
            </div>
            <div className="summary-card">
              <div className="summary-icon appointment-icon">📅</div>
              <div className="summary-details">
                <h3>Agendamentos</h3>
                <p className="summary-value">{agendamentos.length}</p>
              </div>
            </div>
            <div className="summary-card">
              <div className="summary-icon next-appointment-icon">⏰</div>
              <div className="summary-details">
                <h3>Próxima Consulta</h3>
                <p className="summary-value">
                  {agendamentos.length > 0 ? formatarData(agendamentos[0].data) : "Nenhuma"}
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Seção de Próximos Agendamentos */}
        <section className="dashboard-section appointments-section">
          <div className="section-header">
            <h2>Próximos Agendamentos</h2>
            <Link to="/agendamentos" className="view-all">Ver todos</Link>
          </div>
          
          <div className="appointments-list">
            {agendamentos.length > 0 ? (
              agendamentos.map((agendamento) => (
                <div className="appointment-card" key={agendamento.id_agendamento}>
                  <div className="appointment-info">
                    <p className="appointment-service">{agendamento.servico.nome}</p>
                    <p className="appointment-pet">Pet: {agendamento.pet.nome}</p>
                  </div>
                  <div className="appointment-date">
                    <p className="date">{formatarData(agendamento.data)}</p>
                    <p className="time">{agendamento.horario}</p>
                    <span className={`status ${agendamento.status.toLowerCase()}`}>
                      {agendamento.status}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <p className="no-data">Nenhum agendamento encontrado</p>
            )}
          </div>
          
          <div className="action-button">
            <Link to="/novo-agendamento" className="btn-primary">Agendar Serviço</Link>
          </div>
        </section>
        
        {/* Layout de duas colunas para Pets e Serviços em telas maiores */}
        <div className="two-column-section">
          {/* Seção de Meus Pets */}
          <section className="dashboard-section pets-section">
            <div className="section-header">
              <h2>Meus Pets</h2>
              <Link to="/pets" className="view-all">Ver todos</Link>
            </div>
            
            <div className="pets-list">
              {pets.length > 0 ? (
                pets.map((pet) => (
                  <div className="pet-card" key={pet.id_pet}>
                    <div className="pet-avatar">
                      {pet.foto ? (
                        <img src={pet.foto} alt={pet.nome} />
                      ) : (
                        <div className="default-avatar">{pet.nome.charAt(0)}</div>
                      )}
                    </div>
                    <div className="pet-info">
                      <h3>{pet.nome}</h3>
                      <p>{pet.especie} • {pet.raca} • {pet.idade} anos</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="no-data">Nenhum pet cadastrado</p>
              )}
            </div>
            
            <div className="action-button">
              <Link to="/novo-pet" className="btn-primary">Adicionar Pet</Link>
            </div>
          </section>
          
          {/* Seção de Serviços Disponíveis */}
          <section className="dashboard-section services-section">
            <div className="section-header">
              <h2>Serviços Disponíveis</h2>
              <Link to="/servicos" className="view-all">Ver todos</Link>
            </div>
            
            <div className="services-list">
              {servicos.length > 0 ? (
                servicos.map((servico) => (
                  <div className="service-card" key={servico.id_servico}>
                    <h3>{servico.nome}</h3>
                    <p>{servico.descricao}</p>
                    <p className="service-price">R$ {servico.preco.toFixed(2)}</p>
                    <Link to={`/servicos/${servico.id_servico}`} className="btn-outline">
                      Ver Detalhes
                    </Link>
                  </div>
                ))
              ) : (
                <p className="no-data">Nenhum serviço disponível</p>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;