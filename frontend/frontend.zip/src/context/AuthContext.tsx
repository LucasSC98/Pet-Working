"use client"

import { createContext, useState, useEffect, type ReactNode } from "react"
import { useNavigate } from "react-router-dom"
import api from "../services/api"

interface User {
  id: number
  nome: string
  email: string
  token: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  loading: boolean
  login: (email: string, senha: string) => Promise<void>
  register: (nome: string, email: string, senha: string) => Promise<void>
  logout: () => void
  error: string | null
}

export const AuthContext = createContext<AuthContextType>({} as AuthContextType)

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const navigate = useNavigate()

  useEffect(() => {
    const storedUser = localStorage.getItem("@PetWorking:user")

    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }

    setLoading(false)
  }, [])

  const login = async (email: string, senha: string) => {
    try {
      setLoading(true)
      setError(null)

      const response = await api.post("/autenticacao/login", { email, senha })

      const userData = {
        id: response.data.usuario.id,
        nome: response.data.usuario.nome,
        email: response.data.usuario.email,
        token: response.data.token,
      }

      localStorage.setItem("@PetWorking:user", JSON.stringify(userData))
      setUser(userData)
      navigate("/home")
    } catch (err: any) {
      setError(err.response?.data?.message || "Erro ao fazer login")
    } finally {
      setLoading(false)
    }
  }

  const register = async (nome: string, email: string, senha: string) => {
    try {
      setLoading(true)
      setError(null)

      await api.post("/usuarios", { nome, email, senha })

      navigate("/login")
    } catch (err: any) {
      setError(err.response?.data?.message || "Erro ao cadastrar")
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    localStorage.removeItem("@PetWorking:user")
    setUser(null)
    navigate("/login")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        loading,
        login,
        register,
        logout,
        error,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

