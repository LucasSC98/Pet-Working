import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Home from "./pages/Home";
import { useEffect } from "react";
import Dashboard from "./pages/Dashboard";

const BodyClassHandler = () => {
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname.replace("/", ""); // Transforma "/about" em "about"
    document.body.className = path || "login"; // Define a classe do body

    return () => {
      document.body.className = ""; // Remove ao sair
    };
  }, [location]);

  return null;
};

function App() {
  return (
    <Router>
      <BodyClassHandler />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/cadastro" element={<Cadastro />} />
        <Route path="/home" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
